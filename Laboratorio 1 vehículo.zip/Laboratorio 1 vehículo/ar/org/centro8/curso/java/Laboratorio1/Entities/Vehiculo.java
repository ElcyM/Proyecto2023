package ar.org.centro8.curso.java.Laboratorio1.Entities;

public abstract class Vehiculo {
            
    private String marca;
    private String modelo;
    private String color;
    private Integer precio;
    private Radio radio;

    public Vehiculo(String marca, String modelo, String color, Integer precio) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.precio = precio;
    }

    public Vehiculo(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getColor() {
        return color;
    }

    public Integer getPrecio() {
        return precio;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setPrecio(Integer precio) {
        this.precio = precio;
    }

    @Override
    public String toString() {
        return "Vehiculo [marca=" + marca + ", modelo=" + modelo + ", color=" + color + ", Radio=" + radio + ", precio=" + precio + "]";
    }
    public void asignarUnaRadio(String marca, String potencia){
        this.radio = new Radio(marca, potencia);
    }
}




