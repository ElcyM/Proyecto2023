package ar.org.centro8.curso.java.Laboratorio1.Test;

import ar.org.centro8.curso.java.Laboratorio1.Entities.AutoClasico;
import ar.org.centro8.curso.java.Laboratorio1.Entities.AutoNuevo;
import ar.org.centro8.curso.java.Laboratorio1.Entities.Colectivo;
import ar.org.centro8.curso.java.Laboratorio1.Entities.Radio;

public class TestDiagrama {
    public static void main(String[] args) {
        //AutoClasico auto1 = new AutoClasico("Fiat", "Cronos", "Rojo", "Aiwa", "100w");
        AutoClasico fitito = new AutoClasico("Fiat", "Cronos", "Rojo", "Aiwa", "100w");
        System.out.println(fitito.toString());
        AutoClasico falcon = new AutoClasico("Ford", "Falcon", "Blanco");
        System.out.println(falcon.toString());
        fitito.asignarUnaRadio("pionner", "150w");
        System.out.println("Fitito con la radio agregada " + fitito.toString());

        AutoNuevo peugeot = new AutoNuevo("Peugeot", "208", "Negro", "Sony", "200w");
        System.out.println(peugeot.toString());
        peugeot.setPrecio(800000);
        peugeot.asignarUnaRadio("Sony", "400w");
        
        Colectivo mercedes = new Colectivo("Mercedes","Benz", "Azul");
        System.out.println(mercedes.toString());
        mercedes.setPrecio(900000);
        mercedes.asignarUnaRadio("Sony", "150w");

        Radio sony = new Radio("Sony", "300w");
        System.out.println(sony.toString());





    }

}