package ar.org.centro8.curso.java.Laboratorio1.Entities;

public class AutoClasico extends Vehiculo{
    //constructor con precio y sin radio
    public AutoClasico(String marca, String modelo, String color, Integer precio) {
        super(marca, modelo, color, precio);
    }
    //constructor con precio y con radio
    public AutoClasico(String marca, String modelo, String color, Integer precio, String marcaRadio, String potencia) {
        super(marca, modelo, color, precio);
        super.asignarUnaRadio(marcaRadio, potencia);
    }
    //constructor sin precio y sin radio
    public AutoClasico(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }
    //constructor sin precio y con radio
    public AutoClasico(String marca, String modelo, String color, String marcaRadio, String potencia) {
        super(marca, modelo, color);
        super.asignarUnaRadio(marcaRadio, potencia);
    }
}
