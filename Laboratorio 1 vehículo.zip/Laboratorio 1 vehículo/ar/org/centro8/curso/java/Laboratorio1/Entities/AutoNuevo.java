package ar.org.centro8.curso.java.Laboratorio1.Entities;

public class AutoNuevo extends Vehiculo{

    public AutoNuevo(String marca, String modelo, String color, Integer precio, String marcaRadio, String potencia) {
        super(marca, modelo, color, precio);
        super.asignarUnaRadio(marcaRadio, potencia);
    }
    
    public AutoNuevo(String marca, String modelo, String color, String marcaRadio, String potencia) {
        super(marca, modelo, color);
        super.asignarUnaRadio(marcaRadio, potencia);
    }
    
}
