package ar.org.centro8.curso.java.Laboratorio1.Entities;

public final class Colectivo extends Vehiculo{
  //constructor con precio y sin radio
  public Colectivo(String marca, String modelo, String color, Integer precio) {
    super(marca, modelo, color, precio);
}
//constructor con precio y con radio
public Colectivo(String marca, String modelo, String color, Integer precio, String marcaRadio, String potencia) {
    super(marca, modelo, color, precio);
    super.asignarUnaRadio(marcaRadio, potencia);
}
//constructor sin precio y sin radio
public Colectivo(String marca, String modelo, String color) {
    super(marca, modelo, color);
}
//constructor sin precio y con radio
public Colectivo(String marca, String modelo, String color, String marcaRadio, String potencia) {
    super(marca, modelo, color);
    super.asignarUnaRadio(marcaRadio, potencia);
}

}  
    


    

