package ar.org.centro8.curso.java.Laboratorio1.Entities;

public class Radio{
    private String marca;
    private String potencia;

    public Radio(String marca, String potencia) {
        this.marca = marca;
        this.potencia = potencia;
    }

    public String getMarca() {
        return marca;
    }
    public String getPotencia() {
        return potencia;
    }
    public void setMarca(String marca) {
        this.marca = marca;
    }
    public void setPotencia(String potencia) {
        this.potencia = potencia;
    }

    @Override
    public String toString() {
        return "Radio [marca=" + marca + ", potencia=" + potencia + "]";
    }
}